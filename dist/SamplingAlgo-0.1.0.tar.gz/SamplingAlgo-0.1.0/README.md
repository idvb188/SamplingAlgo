# Sampling Algorithms

This package an implementation of the Metropolis-Hastings algorithm for generating samples from a probability distribution.

## Installation

```bash
pip install SamplingAlgo
